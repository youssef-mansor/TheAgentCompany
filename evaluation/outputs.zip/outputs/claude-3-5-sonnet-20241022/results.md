
# Evaluation Results Report

## Results per File

*Sorted by result (⭐ indicates perfect completion)*

| Filename | Total | Result | Steps | Cost |
|----------|-------|--------|-------|------|
| cla-4bit-general | 100 | 100 ⭐ | 32 | 1.54 |
| counter-4bit-general | 100 | 100 ⭐ | 22 | 0.70 |
| d-flip-flop-general | 100 | 100 ⭐ | 24 | 0.88 |
| edge-detector-general | 100 | 100 ⭐ | 15 | 0.52 |
| ipm-caravel | 100 | 100 ⭐ | 5 | 0.21 |
| k-map-4variable-general | 100 | 100 ⭐ | 10 | 0.24 |
| vending-machine-fsm-general | 100 | 95 | 23 | 0.89 |
| uart-general | 100 | 94 | 100 | 20.18 |
| multiplier-4bit-unsigned-pipelined-general | 100 | 82 | 41 | 2.50 |
| shifter-8bit-general | 100 | 82 | 42 | 2.84 |
| uart-integration-caravel | 100 | 80 | 51 | 3.10 |
| gpio-integration-caravel | 100 | 75 | 9 | 0.24 |
| ieee-754-fpu-general | 100 | 53 | 100 | 20.88 |
| riscv-general | 100 | 43 | 99 | 15.28 |
| neural-network-general | 100 | 38 | 99 | 17.43 |

## Summary

**Tasks Evaluated:** 15

**Perfect Completions:** 6/15 (40.00%)

**Overall Score (Average Result):** 82.80

**Average Steps:** 44.80

**Average Cost (USD):** 5.83


## Statistics

| Metric | Value |
|---------|-------|
| Highest Task Result | 100.00 |
| Lowest Task Result | 38.00 |
| Median Task Result | 94.00 |
| Average Task Result | 82.80 |
