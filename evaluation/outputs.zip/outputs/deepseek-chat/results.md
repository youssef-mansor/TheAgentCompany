
# Evaluation Results Report

## Results per File

*Sorted by result (⭐ indicates perfect completion)*

| Filename | Total | Result | Steps | Cost |
|----------|-------|--------|-------|------|
| counter-4bit-general | 100 | 100 ⭐ | 12 | 0.07 |
| edge-detector-general | 100 | 100 ⭐ | 11 | 0.06 |
| ipm-caravel | 100 | 100 ⭐ | 10 | 0.08 |
| shifter-8bit-general | 100 | 92 | 48 | 0.39 |
| gpio-integration-caravel | 100 | 85 | 5 | 0.03 |
| k-map-4variable-general | 100 | 60 | 19 | 0.17 |
| ieee-754-fpu-general | 100 | 53 | 100 | 1.51 |
| cla-4bit-general | 100 | 45 | 100 | 1.73 |
| vending-machine-fsm-general | 100 | 45 | 32 | 0.39 |
| uart-general | 100 | 40 | 40 | 0.71 |
| uart-integration-caravel | 100 | 30 | 21 | 0.13 |
| riscv-general | 100 | 28 | 100 | 1.87 |
| neural-network-general | 100 | 21 | 100 | 1.64 |

## Summary

**Tasks Evaluated:** 13

**Perfect Completions:** 3/13 (23.08%)

**Overall Score (Average Result):** 61.46

**Average Steps:** 46.00

**Average Cost (USD):** 0.67


## Statistics

| Metric | Value |
|---------|-------|
| Highest Task Result | 100.00 |
| Lowest Task Result | 21.00 |
| Median Task Result | 53.00 |
| Average Task Result | 61.46 |
