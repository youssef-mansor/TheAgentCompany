
# Evaluation Results Report

## Results per File

*Sorted by result (⭐ indicates perfect completion)*

| Filename | Total | Result | Steps | Cost |
|----------|-------|--------|-------|------|
| counter-4bit-general | 100 | 100 ⭐ | 22 | 0.38 |
| edge-detector-general | 100 | 100 ⭐ | 29 | 0.57 |
| ipm-caravel | 100 | 100 ⭐ | 5 | 0.14 |
| shifter-8bit-general | 100 | 60 | 37 | 0.84 |
| k-map-4variable-general | 100 | 50 | 99 | 4.83 |
| neural-network-general | 100 | 47 | 53 | 1.80 |
| vending-machine-fsm-general | 100 | 45 | 100 | 4.97 |
| riscv-general | 100 | 34 | 88 | 4.45 |
| cla-4bit-general | 100 | 30 | 100 | 5.52 |
| uart-integration-caravel | 100 | 30 | 42 | 0.95 |
| ieee-754-fpu-general | 100 | 28 | 41 | 1.29 |
| gpio-integration-caravel | 100 | 15 | 3 | 0.04 |
| uart-general | 100 | 13 | 56 | 1.96 |

## Summary

**Tasks Evaluated:** 13

**Perfect Completions:** 3/13 (23.08%)

**Overall Score (Average Result):** 50.15

**Average Steps:** 51.92

**Average Cost (USD):** 2.13


## Statistics

| Metric | Value |
|---------|-------|
| Highest Task Result | 100.00 |
| Lowest Task Result | 13.00 |
| Median Task Result | 45.00 |
| Average Task Result | 50.15 |
